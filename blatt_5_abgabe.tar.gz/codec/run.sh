make install
#../install/bin/image_encoder -s -d -z cpu -i passau.pgm -o out_cpu
srun -p anywhere --gres=gpu -n 1 ../install/bin/image_encoder -s -d -z gpu -i TrueMarbe8192x4096.pgm -o out_gpu
#../install/bin/image_encoder -d -z cpu -i passau.pgm -o out_cpu
#../install/bin/image_encoder -s -c -z seq -i TrueMarbe8192x4096.pgm -o out_seq

#../install/bin/viewer out_seq
#../install/bin/viewer out_gpu
